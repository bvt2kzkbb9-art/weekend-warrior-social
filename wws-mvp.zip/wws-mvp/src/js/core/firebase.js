/**
 * Firebase Setup - CORE MVP
 * Loaded from window.FIREBASE_CONFIG injected in HTML
 */

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, GoogleAuthProvider } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import {
  getFirestore, collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc,
  query, where, orderBy, limit, startAfter, onSnapshot, serverTimestamp,
  arrayUnion, arrayRemove, addDoc, increment, writeBatch, documentId,
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

// Firebase config from window (injected in HTML)
const firebaseConfig = window.FIREBASE_CONFIG || {
  apiKey: "AIzaSyA9I-uUmWLLjq8WNrAgnlmXQxiAgRR1U98",
  authDomain: "weekend-warrior-social-ed3d0.firebaseapp.com",
  projectId: "weekend-warrior-social-ed3d0",
  messagingSenderId: "487311448505",
  appId: "1:487311448505:web:ffbe035b92efa8fc193e68",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

// Collections
export const COL = { USERS: "users" };

// Ranks
export const RANKS = [
  { id: "Rookie", label: "Rookie", min: 0, emoji: "🥉" },
  { id: "Warrior", label: "Warrior", min: 500, emoji: "🥈" },
  { id: "Champion", label: "Champion", min: 2000, emoji: "🥇" },
  { id: "Legend", label: "Legend", min: 10000, emoji: "👑" },
];

export function getRank(points = 0) {
  const p = Number(points) || 0;
  for (let i = RANKS.length - 1; i >= 0; i--) {
    if (p >= RANKS[i].min) return RANKS[i];
  }
  return RANKS[0];
}

export function getLevel(points = 0) {
  return Math.floor((Number(points) || 0) / 500) + 1;
}

// Re-export Firestore API
export {
  collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc,
  query, where, orderBy, limit, startAfter, onSnapshot, serverTimestamp,
  arrayUnion, arrayRemove, addDoc, increment, writeBatch, documentId,
};
