/**
 * Authentication Module - CORE MVP
 * Handles: Register, Login, Logout, Password Reset
 */

import { auth, db, COL } from "./firebase.js";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { doc, getDoc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

/**
 * Create user document in Firestore
 */
async function ensureUserDoc(user) {
  const ref = doc(db, COL.USERS, user.uid);
  const snap = await getDoc(ref).catch(() => null);

  if (!snap || !snap.exists()) {
    await setDoc(ref, {
      uid: user.uid,
      email: user.email,
      username: user.displayName || user.email.split("@")[0],
      xp: 0,
      level: 1,
      rank: "Rookie",
      streak: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }
  return snap?.data() || {};
}

/**
 * REGISTER - Create new user account
 */
export async function register(email, password, displayName) {
  const { user } = await createUserWithEmailAndPassword(auth, email, password);
  await ensureUserDoc({ ...user, displayName });
  return user;
}

/**
 * LOGIN - Authenticate existing user
 */
export async function login(email, password) {
  const { user } = await signInWithEmailAndPassword(auth, email, password);
  await ensureUserDoc(user);
  return user;
}

/**
 * LOGOUT - Sign out current user
 */
export async function logout() {
  await signOut(auth);
  window.location.href = "login.html";
}

/**
 * PASSWORD RESET - Send reset email
 */
export async function resetPassword(email) {
  await sendPasswordResetEmail(auth, email);
}

/**
 * ON AUTH CHANGE - Listen for auth state changes
 */
export function onAuthChange(callback) {
  return onAuthStateChanged(auth, callback);
}

/**
 * INIT REGISTER FORM - Setup register page
 */
export function initRegisterForm() {
  const form = document.getElementById("register-form");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("display-name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirm = document.getElementById("confirm-password").value;
    const errorEl = document.getElementById("error-msg");

    // Validate
    if (!name || !email || !password || !confirm) {
      if (errorEl) errorEl.textContent = "Wypełnij wszystkie pola";
      return;
    }

    if (password.length < 6) {
      if (errorEl) errorEl.textContent = "Hasło musi mieć min. 6 znaków";
      return;
    }

    if (password !== confirm) {
      if (errorEl) errorEl.textContent = "Hasła nie są zgodne";
      return;
    }

    try {
      await register(email, password, name);
      alert("✅ Konto utworzone! Zaloguj się.");
      window.location.href = "login.html";
    } catch (err) {
      const msg = 
        err.code === "auth/email-already-in-use" ? "Email już w użyciu" :
        err.code === "auth/invalid-email" ? "Niepoprawny email" :
        err.code === "auth/weak-password" ? "Hasło za słabe" :
        err.message;
      if (errorEl) errorEl.textContent = "❌ " + msg;
    }
  });
}

/**
 * INIT LOGIN FORM - Setup login page
 */
export function initLoginForm() {
  const form = document.getElementById("login-form");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const errorEl = document.getElementById("error-msg");

    if (!email || !password) {
      if (errorEl) errorEl.textContent = "Podaj email i hasło";
      return;
    }

    try {
      await login(email, password);
      window.location.href = "dashboard.html";
    } catch (err) {
      const msg = 
        err.code === "auth/user-not-found" ? "Użytkownik nie znaleziony" :
        err.code === "auth/wrong-password" ? "Niepoprawne hasło" :
        err.code === "auth/invalid-credential" ? "Niepoprawny email lub hasło" :
        err.message;
      if (errorEl) errorEl.textContent = "❌ " + msg;
    }
  });

  // Password reset link
  const forgotLink = document.getElementById("forgot-link");
  if (forgotLink) {
    forgotLink.addEventListener("click", async (e) => {
      e.preventDefault();
      const email = document.getElementById("email").value.trim();
      if (!email) {
        alert("Wpisz email");
        return;
      }
      try {
        await resetPassword(email);
        alert("✅ Link resetowania wysłany na email!");
      } catch (err) {
        alert("❌ Błąd: " + err.message);
      }
    });
  }
}

/**
 * INIT RESET FORM - Setup password reset page
 */
export function initResetForm() {
  const form = document.getElementById("reset-form");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();
    const errorEl = document.getElementById("error-msg");

    if (!email) {
      if (errorEl) errorEl.textContent = "Podaj email";
      return;
    }

    try {
      await resetPassword(email);
      if (errorEl) errorEl.textContent = "✅ Email resetowania wysłany!";
      if (errorEl) errorEl.style.color = "green";
    } catch (err) {
      if (errorEl) errorEl.textContent = "❌ " + err.message;
    }
  });
}

/**
 * REQUIRE LOGIN - Protect page (redirect if not logged in)
 */
export function requireLogin() {
  return new Promise((resolve) => {
    onAuthChange((user) => {
      if (!user) {
        window.location.href = "login.html";
        return;
      }
      resolve(user);
    });
  });
}

/**
 * REQUIRE LOGOUT - Redirect logged-in users
 */
export function requireLogout() {
  return new Promise((resolve) => {
    onAuthChange((user) => {
      if (user) {
        window.location.href = "dashboard.html";
      }
      resolve(!user);
    });
  });
}

/**
 * GET CURRENT USER - Get auth + Firestore data
 */
export async function getCurrentUser() {
  return new Promise((resolve) => {
    onAuthChange(async (authUser) => {
      if (!authUser) {
        resolve(null);
        return;
      }

      const userDoc = await getDoc(doc(db, COL.USERS, authUser.uid)).catch(() => null);
      resolve({
        auth: authUser,
        data: userDoc?.data() || {},
      });
    });
  });
}
