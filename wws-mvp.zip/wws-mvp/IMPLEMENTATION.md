// ============================================================
// WEEKEND WARRIOR SOCIAL MVP — IMPLEMENTATION GUIDE
// ============================================================
// 
// Czysty projekt z TYLKO:
// ✅ Landing page (landing.html)
// ✅ Login (login.html)
// ✅ Register (register.html)
// ✅ Password Reset (forgot-password.html)
// ✅ Dashboard (dashboard.html)
// ✅ Firestore user storage
// ✅ Firebase Auth
// 
// ============================================================

## 📋 WYMAGANIA

- Firebase account (console.firebase.google.com)
- GitHub account (github.com)
- Node.js (dla local dev)
- Firebase CLI (dla deployment)

---

## 🚀 KROK PO KROKU

### KROK 1: Firebase Project Setup (10 min)

1. Przejdź na: https://console.firebase.google.com
2. Kliknij "Create Project" → Weekend Warrior Social
3. Enable Google Analytics (opcjonalnie)
4. Kliknij "Create"

#### Enable Authentication:
1. Lewe menu → "Authentication"
2. Kliknij "Get Started"
3. Wybierz "Email/Password"
4. Enable toggle → Kliknij "Enable" → "Save"

#### Enable Firestore:
1. Lewe menu → "Firestore Database"
2. Kliknij "Create Database"
3. Wybierz: "Start in test mode" (dla MVP)
4. Lokacja: "eur3" (Europe)
5. Kliknij "Create"

#### Pobierz credentials:
1. Project Settings (koło zębate) → "Project settings"
2. Scroll do "Your apps"
3. Kliknij ikona Web "</>"
4. Copy config (pamiętaj firebase.json wartości!)

### KROK 2: Lokalny Setup (5 min)

```bash
# Clone/Setup repo
cd path/to/project

# Install Firebase CLI (jeśli nie masz)
npm install -g firebase-tools

# Login to Firebase
firebase login

# Upewnij się że jesteś w katalogu z firebase.json
firebase projects:list

# Set project ID
firebase use weekend-warrior-social-ed3d0
# (lub twój project ID)
```

### KROK 3: Deploy Firestore Rules (2 min)

```bash
# Z katalogu projektu
firebase deploy --only firestore:rules

# Sprawdź czy OK
firebase describe firestore
```

### KROK 4: Test Lokalnie (5 min)

```bash
# Start dev server
npm run dev

# Otwórz browser
open http://localhost:5500

# Test:
# 1. Landing page powinien być widoczny
# 2. Kliknij "Dołącz" → Register page
# 3. Wpisz: name, email, password
# 4. Stwórz konto
# 5. Powinieneś być redirectowany na login
# 6. Zaloguj się
# 7. Powinieneś zobaczyć dashboard
```

### KROK 5: GitHub Setup (10 min)

```bash
# Stwórz GitHub repo
# https://github.com/new

# Przypisz repo lokalnie
git remote add origin https://github.com/YOUR_USERNAME/weekend-warrior-social.git

# Initial commit
git add .
git commit -m "Initial commit: MVP with auth"
git branch -M main
git push -u origin main
```

### KROK 6: Firebase Secrets (5 min)

**TYLKO jeśli chcesz GitHub Actions deployment**

1. Przejdź do GitHub repo → Settings → Secrets and variables → Actions
2. Kliknij "New repository secret"

**Secret 1: FIREBASE_SERVICE_ACCOUNT**
- Wartość: Zawartość JSON key file
  1. Firebase Console → Project settings → Service accounts
  2. Kliknij "Generate new private key"
  3. Copy całą zawartość JSON
  4. Wklej do GitHub Secret

**Secret 2: FIREBASE_TOKEN**
```bash
firebase login:ci
# Będziesz redirectowany do login
# Copy token z output
# Wklej do GitHub Secret
```

### KROK 7: Deploy do Firebase Hosting (3 min)

```bash
# Z katalogu projektu
firebase deploy

# Output będzie zawierał: "Hosting URL: https://..."
# To twoja aplikacja!
```

---

## 🎯 CO TERAZ?

Aplikacja je gotowa! Ale MVP ma BRAKOWAĆ funkcji:

### TODO - PHASE 2:

- [ ] Challenges (wyzwania)
- [ ] Leaderboard (ranking)
- [ ] XP system (punkty)
- [ ] User profiles (profile)
- [ ] Messaging (czat)
- [ ] Feed (posty)
- [ ] Notifications
- [ ] Mobile app (React Native)

### Dla każdej funkcji:
1. Stwórz HTML page (page.html)
2. Stwórz CSS (css/page.css)
3. Stwórz JavaScript (src/js/page.js)
4. Link w main navigation
5. Update firestore.rules jeśli potrzeba
6. Deploy: `firebase deploy`

---

## 🔒 SECURITY CHECKLIST

- ✅ Firebase credentials w HTML (safe - public API)
- ✅ Firestore rules restrictive (users tylko swoje dane)
- ✅ HTTPS enabled (Firebase default)
- ✅ .gitignore chroni sekrety

---

## 🐛 TROUBLESHOOTING

### Problem: "Cannot read properties of undefined"

```
❌ w browser console
✅ Solution:
  1. Otwórz DevTools (F12)
  2. Sprawdź Console tab
  3. Sprawdź Network tab
  4. Upewnij się że firebase config jest w HTML
```

### Problem: "Permission denied" in Firestore

```
❌ Error when creating account
✅ Solution:
  1. Firebase Console → Firestore
  2. Rules tab
  3. Upewnij się że rules są deployed
  4. Run: firebase deploy --only firestore:rules
```

### Problem: "Email already exists"

```
✅ To jest EXPECTED
   - User account już istnieje
   - Użytkownik powinien użyć login zamiast register
```

### Problem: App is blank white screen

```
❌ No content showing
✅ Solution:
  1. F12 → Console - look for errors
  2. Check Network tab for failed requests
  3. Upewnij się że Firebase config w HTML jest POPRAWNY
```

---

## 📊 PROJECT STRUCTURE

```
wws-mvp/
├── landing.html              ← Public homepage
├── login.html                ← Login form
├── register.html             ← Registration form
├── forgot-password.html      ← Password reset
├── dashboard.html            ← Main app (after login)
├── terms.html                ← Terms of service
│
├── src/
│   └── js/core/
│       ├── firebase.js       ← Firebase setup
│       └── auth.js           ← Auth functions
│
├── css/                      ← (empty - not needed for MVP)
│
├── firebase.json             ← Hosting config
├── firestore.rules           ← Security rules
├── firestore.indexes.json    ← Indexes (empty)
├── package.json              ← NPM config
└── .gitignore                ← Git ignore
```

---

## 🎓 LEARNING RESOURCES

- Firebase Docs: https://firebase.google.com/docs
- Firestore: https://firebase.google.com/docs/firestore
- Firebase Auth: https://firebase.google.com/docs/auth
- ES Modules: https://developer.mozilla.org/en-US/docs/web/javascript/guide/modules

---

## ✅ SUCCESS INDICATORS

Gdy wszystko OK:

1. ✅ Landing page loads at https://your-project.web.app
2. ✅ Can register new account
3. ✅ Firebase Console shows new user in Authentication
4. ✅ Firestore has new document in /users/{uid}
5. ✅ Can login with registered account
6. ✅ Dashboard loads with user info
7. ✅ Can logout
8. ✅ Can reset password via email

---

## 💡 PRO TIPS

1. **Local development**: `npm run dev` → http://localhost:5500
2. **Real-time Firestore**: Open Firebase Console → watch data update
3. **Debug auth**: Browser Console → look for [Firebase] logs
4. **Test auth**: Create test account with: test@test.com / password123
5. **Monitor costs**: Firebase Console → Firestore → Usage

---

## 🆘 NEED HELP?

1. Check browser console (F12)
2. Check Firebase Console logs
3. Read error message carefully
4. Search Google/Firebase docs
5. Check firestore.rules syntax

---

**Version**: 1.0.0 MVP
**Status**: Ready for development
**Last Updated**: June 2024
