# ⚔️ Weekend Warrior Social - MVP

**Minimalist MVP**: Login + Register + Dashboard

**Size**: ~50KB (without node_modules)  
**Files**: 13 (HTML/JS/Rules)  
**Setup Time**: ~30 minutes

---

## 🚀 QUICK START

### 1. Firebase Setup
```bash
# Create project at console.firebase.google.com
# Enable: Auth (Email/Password) + Firestore
```

### 2. Local Test
```bash
npm install
npm run dev
# Open: http://localhost:5500
```

### 3. Deploy
```bash
firebase login
firebase deploy
```

---

## 📁 What's Included

- ✅ **landing.html** - Public homepage
- ✅ **login.html** - User login
- ✅ **register.html** - User registration
- ✅ **forgot-password.html** - Password reset
- ✅ **dashboard.html** - Main app (after login)
- ✅ **Firebase Auth** - Email/password authentication
- ✅ **Firestore** - User data storage
- ✅ **Security Rules** - Firestore rules

---

## 📖 Full Guide

See **IMPLEMENTATION.md** for step-by-step instructions.

---

## 🎯 PHASE 2 (Future)

- Challenges
- Leaderboards
- XP System
- User Profiles
- Messaging
- Feed/Posts
- Mobile App

---

## 💬 Questions?

Read **IMPLEMENTATION.md** or check browser console logs.

---

Made with ❤️ for Warriors
